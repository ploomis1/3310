package sorting;

public interface BinaryInsertion {

}
