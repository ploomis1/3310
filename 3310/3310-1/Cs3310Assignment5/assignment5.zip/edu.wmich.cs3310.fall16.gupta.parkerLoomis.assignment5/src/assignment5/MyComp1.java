package assignment5;
//package edu.wmich.cs3310.fall16.gupta.parkerLoomis.assignment5;
//
//import java.util.Comparator;
//
//class MyComp1 implements Comparator<Integer>
//{
//public int compare(Integer x, Integer y)
//{
//     return y-x;
//}
//}
