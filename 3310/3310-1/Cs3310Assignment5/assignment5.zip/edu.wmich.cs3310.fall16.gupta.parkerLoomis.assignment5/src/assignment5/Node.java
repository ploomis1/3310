package assignment5;
//package edu.wmich.cs3310.fall16.gupta.parkerLoomis.assignment5;
//
//import java.util.Comparator;
//
//public class Node<T>
//{
//   private T data;
//   private Node<T> left, right;
//
//   public Node(T data, Node<T> l, Node<T> r)
//   {
//      left = l; right = r;
//      this.data = data;
//   }
//
//   public Node(T data)
//   {
//      this(data, null, null);
//   }
//
//   public String toString()
//   {
//      return data.toString();
//   }
//} 
