PARKER LOOMIS

just press play and it should do everything. I did use a min heap on the tree.
