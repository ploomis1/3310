package sorting;

import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedList;

public class BuiltIn {

	public BuiltIn() {
		// TODO Auto-generated constructor stub
	}
	public static void In(float [] b){
		Arrays.sort(b);
	}
	public static void In(LinkedList b){
		Collections.sort(b);
	}
	
}
