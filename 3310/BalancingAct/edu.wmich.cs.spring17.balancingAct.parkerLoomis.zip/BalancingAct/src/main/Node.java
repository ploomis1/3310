package main;



public class Node {
	int depth;
	Node parent;
	Node leftchild;
	Node rightchild;
	String var;
	
	public Node(int depth){
		this.depth = depth;
		
	}
	
	public void addNode(String vars ){
		
		this.var=vars;
	}
	public String getString(){
		return this.var;
	}
	public void setRight(String var){
		this.rightchild.var=var;
	}
	public void setLeft(String var){
		this.leftchild.var=var;
	}
	public String getRight(){
		return this.rightchild.getString();
	}
	public String getLeft(){
		return this.leftchild.getString();
	
	}
	

}







